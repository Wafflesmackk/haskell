--Daka Bence I5RQFI
module Homework8 where
    import Data.Char

    testFile0 :: File 
    testFile0 = ["asd  qwe", "-- Foo", "", "\thello world "]
    
    type Line = String
    type File = [Line]
    
    --1 feladat
    countWordsInLine :: Line -> Int
    countWordsInLine x = length (words x)

    --2 feladat
    countWords :: File -> Int
    countWords [] = 0
    countWords (x:xs) = countWordsInLine x + countWords xs

    --3 feladat
    countCharsInLine :: Line -> Int
    countCharsInLine [] = 0
    countCharsInLine (x:xs) = 1 + countCharsInLine xs

    countChars :: File -> Int
    countChars [] = 0
    countChars (x:xs) = countCharsInLine x + countChars xs

    
    --4 feladat
    capitalizeWord :: String -> String
    capitalizeWord [] = []
    capitalizeWord (x:xs) = (toUpper x) : xs

    capitalizeWordsInLine :: Line -> Line
    capitalizeWordsInLine [] = []
    capitalizeWordsInLine a
        | null (tail (words a )) = capitalizeWord (head (words a))
        | otherwise = capitalizeWord (head (words a)) ++ " " ++  capitalizeWordsInLine (unwords (tail (words a)))

    --5 feladat
    isComment :: Line -> Bool
    isComment "" = False
    isComment (x:xs)
        | null xs = False
        | x == '-' && head xs == '-' = True
        | otherwise = False

    --6 feladat
    dropComments :: File -> File
    dropComments [] = []
    dropComments (x:xs) 
        | isComment x = dropComments xs
        | otherwise = x : dropComments xs

    --7 feladat
    numberLines :: File -> File
    numberLines [] = []
    numberLines x = (numberLines (init x)) ++ [(intToDigit (length x)) : ": " ++ (last x)]

    --8 feladat
    dropTrailingWhitespaces :: Line -> Line
    dropTrailingWhitespaces [] = [] 
    dropTrailingWhitespaces a
        | isSpace (last a) == False = a
        | otherwise =  dropTrailingWhitespaces (init a)

    --9 feladat
    spaceGenerator :: Int -> [Char]
    spaceGenerator 0 = ""
    spaceGenerator a = " " ++ spaceGenerator (a-1)

    replaceTab :: Int -> Char -> [Char]
    replaceTab a x 
        | x == '\t' = spaceGenerator a
        | otherwise = [x]

    --10 feladat
    replaceTabInLine :: Int -> Line -> Line
    replaceTabInLine _ [] = []
    replaceTabInLine a (x:xs) = (replaceTab a x) ++ (replaceTabInLine a xs)


    replaceTabs :: Int -> File -> File
    replaceTabs _ [] = []
    replaceTabs a (x:xs) = (replaceTabInLine a x) : (replaceTabs a xs)